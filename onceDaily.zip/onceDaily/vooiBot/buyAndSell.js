require('dotenv').config();
const axios = require('axios');
const crypto = require('crypto');

// Load environment variables
const { ACCOUNT_ID, ORDERLY_API_KEY, ORDERLY_SECRET } = process.env;

// Helper function to generate API signature
function generateSignature(payload) {
  return crypto
    .createHmac('sha256', ORDERLY_SECRET)
    .update(payload)
    .digest('hex');
}

// Function to place an order
async function placeOrder(orderType, amount, price, side) {
  const endpoint = "https://api.orderly.network/v1/orders"; // Adjust endpoint if necessary

  const payload = {
    account_id: ACCOUNT_ID,
    type: orderType, // "LIMIT" or "MARKET"
    amount: amount, // Trade amount (in USDC or target asset)
    price: price, // Price per unit (only for LIMIT orders)
    side: side, // "BUY" or "SELL"
  };

  const payloadString = JSON.stringify(payload);
  const signature = generateSignature(payloadString);

  try {
    const response = await axios.post(endpoint, payload, {
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ORDERLY_API_KEY,
        'x-api-signature': signature,
      },
    });

    console.log(`Order placed: ${JSON.stringify(response.data)}`);
    return response.data;
  } catch (error) {
    console.error(`Error placing order: ${error.response ? error.response.data : error.message}`);
  }
}

// Example usage
(async () => {
  const orderType = "MARKET"; // "MARKET" or "LIMIT"
  const amount = 60; // USDC
  const price = 1; // Price (only needed for LIMIT orders)
  const side = "BUY"; // "BUY" or "SELL"

  // Place a BUY order
  console.log("Placing BUY order...");
  await placeOrder(orderType, amount, price, side);

  // Place a SELL order
  console.log("Placing SELL order...");
  await placeOrder(orderType, amount, price, "SELL");
})();
