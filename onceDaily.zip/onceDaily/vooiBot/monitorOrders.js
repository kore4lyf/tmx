require('dotenv').config();
const axios = require('axios');
const crypto = require('crypto');

// Load environment variables
const { ACCOUNT_ID, ORDERLY_API_KEY, ORDERLY_SECRET } = process.env;

// Helper function to generate API signature
function generateSignature(payload) {
  return crypto
    .createHmac('sha256', ORDERLY_SECRET)
    .update(payload)
    .digest('hex');
}

// Function to fetch open orders
async function fetchOpenOrders() {
  const endpoint = "https://api.orderly.network/v1/orders/open"; // Adjust endpoint if necessary

  const payload = {
    account_id: ACCOUNT_ID,
  };

  const payloadString = JSON.stringify(payload);
  const signature = generateSignature(payloadString);

  try {
    const response = await axios.get(endpoint, {
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ORDERLY_API_KEY,
        'x-api-signature': signature,
      },
      params: payload,
    });

    if (response.data.orders.length === 0) {
      console.log("No open orders.");
    } else {
      console.log("Open Orders:");
      response.data.orders.forEach((order) => {
        console.log(`Order ID: ${order.id}`);
        console.log(`Type: ${order.type}`);
        console.log(`Amount: ${order.amount}`);
        console.log(`Price: ${order.price}`);
        console.log(`Status: ${order.status}`);
        console.log('---------------------------');
      });
    }
  } catch (error) {
    console.error(`Error fetching open orders: ${error.response ? error.response.data : error.message}`);
  }
}

// Monitor open orders
(async () => {
  console.log("Fetching open orders...");
  await fetchOpenOrders();
})();
