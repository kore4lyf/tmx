#!/usr/bin/expect -ff

# Start the PM2-managed Python script
spawn pm2 start python3 example.py --name "wonton"


expect "auto clear task y/n : "
send "y"

expect "auto play game y/n : "
send "y"

expect "auto fusion wonton y/n : "
send "y"

expect "auto upgrade badge y/n :"
send "y"

expect "auto buy basic box y/n : "
send "n"

expect "auto sell wonton & bowl y/n : "
send "n"

expect "basic score wonton *80-100 = y, basic score wonton *50-80 = n :"
send "y"

# Wait for the process to finish
expect eof
