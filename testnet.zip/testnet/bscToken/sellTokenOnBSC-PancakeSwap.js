// Import required dependencies
const { ethers } = require("ethers");
const { createPublicClient, http } = require("viem");
const { bsc } = require("viem/chains");
require("dotenv").config();
const fs = require("fs");
const readline = require("readline");

// Load config and environment variables
const config = JSON.parse(fs.readFileSync("config.json"));

// Constants
const PANCAKESWAP_ROUTER_ADDRESS = '0x10ED43C718714eb63d5aA57B78B54704E256024E';
const WBNB_ADDRESS = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c'.toLowerCase();
const TOKEN_ADDRESS = config.TOKEN_ADDRESS.toLowerCase()
const DEADLINE = Math.floor(Date.now() / 1000) + 300; // 5 minutes from now

// Full Router ABI (only the methods we need)
const ROUTER_ABI = [
    "function swapExactTokensForETHSupportingFeeOnTransferTokens(uint256 amountIn, uint256 amountOutMin, address[] calldata path, address to, uint256 deadline) external returns (uint[] memory amounts)",
    "function getAmountsOut(uint256 amountIn, address[] memory path) external view returns (uint256[] memory amounts)",
    "function WETH() external pure returns (address)"
];

const TOKEN_ABI = [
    "function approve(address spender, uint256 amount) external returns (bool)",
    "function balanceOf(address account) external view returns (uint256)",
    "function decimals() external view returns (uint8)",
    "function allowance(address owner, address spender) external view returns (uint256)"
];

// Create readline interface
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Enhanced gas price calculation function
async function getGasPrices(provider) {
    const baseGasPrice = await provider.getGasPrice();
    const pendingBlock = await provider.getBlock('pending');
    const baseFeePerGas = pendingBlock.baseFeePerGas || baseGasPrice;

    // Calculate gas prices with different multipliers
    const slow = baseGasPrice.mul(75).div(100);      // 75% of current price
    const standard = baseGasPrice;                    // Current price
    const fast = baseGasPrice.mul(125).div(100);     // 125% of current price

    // Ensure minimum gas price
    const minGasPrice = ethers.parseUnits("1", "gwei");
    return {
        slow: ethers.formatUnits(slow.lt(minGasPrice) ? minGasPrice : slow, "gwei"),
        standard: ethers.formatUnits(standard.lt(minGasPrice) ? minGasPrice : standard, "gwei"),
        fast: ethers.formatUnits(fast.lt(minGasPrice) ? minGasPrice : fast, "gwei"),
        baseFeePerGas: ethers.formatUnits(baseFeePerGas, "gwei")
    };
}

// Enhanced gas options calculation
async function getGasOptions(provider) {
    const gasPrices = await getGasPrices(provider);
    
    const gasOptions = {
        slow: {
            price: parseFloat(gasPrices.slow),
            limit: 500000,
            timeEstimate: '~5 mins',
            priority: 'low'
        },
        standard: {
            price: parseFloat(gasPrices.standard),
            limit: 500000,
            timeEstimate: '~3 mins',
            priority: 'medium'
        },
        fast: {
            price: parseFloat(gasPrices.fast),
            limit: 500000,
            timeEstimate: '~1 min',
            priority: 'high'
        }
    };

    // Calculate costs in BNB
    Object.keys(gasOptions).forEach(speed => {
        gasOptions[speed].costInBNB = (gasOptions[speed].price * gasOptions[speed].limit / 1e9).toFixed(6);
    });

    return {
        options: gasOptions,
        baseFeePerGas: parseFloat(gasPrices.baseFeePerGas)
    };
}

// Function to check if gas price is sufficient
async function isGasPriceSufficient(provider, gasPrice) {
    const pendingBlock = await provider.getBlock('pending');
    const baseFeePerGas = pendingBlock.baseFeePerGas || await provider.getGasPrice();
    return ethers.parseUnits(gasPrice.toString(), "gwei").gte(baseFeePerGas);
}

// Enhanced gas selection prompt
function promptGasSelection(gasOptions, baseFeePerGas) {
    return new Promise((resolve) => {
        console.log('\nCurrent Base Fee:', baseFeePerGas.toFixed(2), 'gwei');
        console.log('\nGas Options:');
        console.log(`1. Slow (${gasOptions.slow.timeEstimate}): ${gasOptions.slow.costInBNB} BNB (${gasOptions.slow.price.toFixed(2)} gwei)`);
        console.log(`2. Standard (${gasOptions.standard.timeEstimate}): ${gasOptions.standard.costInBNB} BNB (${gasOptions.standard.price.toFixed(2)} gwei)`);
        console.log(`3. Fast (${gasOptions.fast.timeEstimate}): ${gasOptions.fast.costInBNB} BNB (${gasOptions.fast.price.toFixed(2)} gwei)`);

        rl.question('\nSelect gas option (1-3): ', (answer) => {
            resolve({
                '1': gasOptions.slow,
                '2': gasOptions.standard,
                '3': gasOptions.fast
            }[answer] || gasOptions.standard);
        });
    });
}

// Function to wait for transaction confirmation with timeout
async function waitForTransaction(provider, txHash, timeout = 300000) { // 5 minutes timeout
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
        const receipt = await provider.getTransactionReceipt(txHash);
        if (receipt) {
            return receipt;
        }
        await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second before checking again
    }
    throw new Error('Transaction confirmation timeout');
}

// Main swap function
async function swapTokensForBNB() {
    try {
        // Setup provider and wallet
        const provider = new ethers.JsonRpcProvider(process.env.RPC_URL);
        const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);

        // Setup contracts
        const tokenContract = new ethers.Contract(TOKEN_ADDRESS, TOKEN_ABI, wallet);
        const routerContract = new ethers.Contract(PANCAKESWAP_ROUTER_ADDRESS, ROUTER_ABI, wallet);

        // Get enhanced gas options
        const { options: gasOptions, baseFeePerGas } = await getGasOptions(provider);
        const selectedGas = await promptGasSelection(gasOptions, baseFeePerGas);

        // Verify gas price is sufficient
        if (!await isGasPriceSufficient(provider, selectedGas.price)) {
            console.log('\nWarning: Selected gas price might be too low. Adjusting to minimum required...');
            selectedGas.price = parseFloat(ethers.formatUnits(await provider.getGasPrice(), "gwei")) * 1.1;
        }

        console.log(`\nSelected gas option: ${selectedGas.price.toFixed(2)} gwei (Estimated cost: ${selectedGas.costInBNB} BNB)`);

        // Get token balance and decimals
        const [balance, decimals] = await Promise.all([
            tokenContract.balanceOf(wallet.address),
            tokenContract.decimals()
        ]);

        console.log(`Token balance: ${ethers.formatUnits(balance, decimals)} tokens`);

        if (balance <= 0) {
            throw new Error('Insufficient token balance');
        }

        // Check existing allowance
        const currentAllowance = await tokenContract.allowance(wallet.address, PANCAKESWAP_ROUTER_ADDRESS);
        
        // Only approve if necessary
        if (currentAllowance < balance) {
            console.log('Approving PancakeSwap router...');
            const approvalTx = await tokenContract.approve(
                PANCAKESWAP_ROUTER_ADDRESS,
                ethers.MaxUint256,
                {
                    gasPrice: ethers.parseUnits(selectedGas.price.toString(), 'gwei'),
                    gasLimit: selectedGas.limit
                }
            );
            
            console.log('Waiting for approval confirmation...');
            const approvalReceipt = await waitForTransaction(provider, approvalTx.hash);
            console.log('Approval successful. Transaction hash:', approvalTx.hash);
        } else {
            console.log('Token already approved');
        }

        // Prepare swap parameters
        const path = [TOKEN_ADDRESS, WBNB_ADDRESS];
        const amountOutMin = 0;

        console.log('Executing swap...');
        
        // Create transaction with proper encoding
        const swapData = routerContract.interface.encodeFunctionData(
            'swapExactTokensForETHSupportingFeeOnTransferTokens',
            [balance, amountOutMin, path, wallet.address, DEADLINE]
        );

        // Send transaction with retry logic
        let retryCount = 0;
        const maxRetries = 3;
        let swapReceipt;

        while (retryCount < maxRetries) {
            try {
                const swapTx = await wallet.sendTransaction({
                    to: PANCAKESWAP_ROUTER_ADDRESS,
                    data: swapData,
                    gasPrice: ethers.parseUnits(selectedGas.price.toString(), 'gwei'),
                    gasLimit: selectedGas.limit
                });

                console.log('Swap transaction sent. Waiting for confirmation...');
                swapReceipt = await waitForTransaction(provider, swapTx.hash);
                
                if (swapReceipt.status === 1) {
                    break;
                } else {
                    throw new Error('Transaction failed');
                }
            } catch (error) {
                retryCount++;
                if (retryCount === maxRetries) {
                    throw error;
                }
                console.log(`Retry attempt ${retryCount}/${maxRetries}...`);
                selectedGas.price *= 1.1; // Increase gas price by 10% for retry
                await new Promise(resolve => setTimeout(resolve, 2000)); // Wait 2 seconds before retry
            }
        }

        console.log('\nSwap successful!');
        console.log('Transaction hash:', swapReceipt.hash);
        console.log('Gas used:', swapReceipt.gasUsed.toString());
        console.log(`View on BSCScan: https://bscscan.com/tx/${swapReceipt.hash}`);

    } catch (error) {
        console.error('\nError occurred:', error.reason || error.message);
        if (error.transaction) {
            console.log('\nTransaction details:');
            console.log('Transaction hash:', error.transaction.hash);
            console.log(`View on BSCScan: https://bscscan.com/tx/${error.transaction.hash}`);
        }
        process.exit(1);
    } finally {
        rl.close();
    }
}

// Execute the swap
swapTokensForBNB().then(() => process.exit(0));
