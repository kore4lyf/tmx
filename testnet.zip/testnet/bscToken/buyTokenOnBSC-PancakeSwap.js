// Import required dependencies
const { ethers } = require("ethers");
const { createPublicClient, http } = require("viem");
const { bsc } = require("viem/chains");
require("dotenv").config();
const fs = require("fs");
const readline = require("readline");

// Load config and environment variables
const config = JSON.parse(fs.readFileSync("config.json"));

// Constants
const PANCAKESWAP_ROUTER_ADDRESS = '0x10ED43C718714eb63d5aA57B78B54704E256024E';
const WBNB_ADDRESS = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c'.toLowerCase();
const DEADLINE = Math.floor(Date.now() / 1000) + 300; // 5 minutes from now

// Router ABI with buy-specific functions
const ROUTER_ABI = [
    "function swapExactETHForTokensSupportingFeeOnTransferTokens(uint256 amountOutMin, address[] calldata path, address to, uint256 deadline) external payable",
    "function getAmountsOut(uint256 amountIn, address[] memory path) external view returns (uint256[] memory amounts)",
    "function WETH() external pure returns (address)"
];

// Create readline interface
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Enhanced gas price calculation function (same as sell script)
async function getGasPrices(provider) {
    const feeData = await provider.getFeeData();
    const baseGasPrice = feeData.gasPrice; // Fetch gas price
    if (!baseGasPrice) {
        throw new Error("Unable to fetch gas price.");
    }

    const slow = (baseGasPrice * 75n) / 100n;
    const standard = baseGasPrice;
    const fast = (baseGasPrice * 125n) / 100n;

    const minGasPrice = ethers.parseUnits("1", "gwei");

    return {
        slow: ethers.formatUnits(slow < minGasPrice ? minGasPrice : slow, "gwei"),
        standard: ethers.formatUnits(standard < minGasPrice ? minGasPrice : standard, "gwei"),
        fast: ethers.formatUnits(fast < minGasPrice ? minGasPrice : fast, "gwei"),
        baseFeePerGas: ethers.formatUnits(baseGasPrice, "gwei"),
    };
}


// Function to get gas options (same as sell script)
async function getGasOptions(provider) {
    const gasPrices = await getGasPrices(provider);
    
    const gasOptions = {
        slow: {
            price: parseFloat(gasPrices.slow),
            limit: 500000,
            timeEstimate: '~5 mins',
            priority: 'low'
        },
        standard: {
            price: parseFloat(gasPrices.standard),
            limit: 500000,
            timeEstimate: '~3 mins',
            priority: 'medium'
        },
        fast: {
            price: parseFloat(gasPrices.fast),
            limit: 500000,
            timeEstimate: '~1 min',
            priority: 'high'
        }
    };

    Object.keys(gasOptions).forEach(speed => {
        gasOptions[speed].costInBNB = (gasOptions[speed].price * gasOptions[speed].limit / 1e9).toFixed(6);
    });

    return {
        options: gasOptions,
        baseFeePerGas: parseFloat(gasPrices.baseFeePerGas)
    };
}

// Function to prompt for BNB amount
function promptBNBAmount() {
    return new Promise((resolve) => {
        rl.question('\nEnter amount of BNB to spend: ', (answer) => {
            resolve(parseFloat(answer));
        });
    });
}

// Gas selection prompt (same as sell script)
function promptGasSelection(gasOptions, baseFeePerGas) {
    return new Promise((resolve) => {
        console.log('\nCurrent Base Fee:', baseFeePerGas.toFixed(2), 'gwei');
        console.log('\nGas Options:');
        console.log(`1. Slow (${gasOptions.slow.timeEstimate}): ${gasOptions.slow.costInBNB} BNB (${gasOptions.slow.price.toFixed(2)} gwei)`);
        console.log(`2. Standard (${gasOptions.standard.timeEstimate}): ${gasOptions.standard.costInBNB} BNB (${gasOptions.standard.price.toFixed(2)} gwei)`);
        console.log(`3. Fast (${gasOptions.fast.timeEstimate}): ${gasOptions.fast.costInBNB} BNB (${gasOptions.fast.price.toFixed(2)} gwei)`);

        rl.question('\nSelect gas option (1-3): ', (answer) => {
            resolve({
                '1': gasOptions.slow,
                '2': gasOptions.standard,
                '3': gasOptions.fast
            }[answer] || gasOptions.standard);
        });
    });
}

// Transaction confirmation wait function (same as sell script)
async function waitForTransaction(provider, txHash, timeout = 300000) {
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
        const receipt = await provider.getTransactionReceipt(txHash);
        if (receipt) {
            return receipt;
        }
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
    throw new Error('Transaction confirmation timeout');
}

// Main function to buy tokens with BNB
async function buyTokensWithBNB() {
    try {
        // Setup provider and wallet
        const provider = new ethers.JsonRpcProvider(process.env.RPC_URL);
        const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);

        // Get wallet BNB balance
        const bnbBalance = await provider.getBalance(wallet.address);
        console.log(`Current BNB Balance: ${ethers.formatEther(bnbBalance)} BNB`);

        // Setup router contract
        const routerContract = new ethers.Contract(
            PANCAKESWAP_ROUTER_ADDRESS,
            ROUTER_ABI,
            wallet
        );

        // Get amount of BNB to spend
        const bnbAmount = await promptBNBAmount();
        if (bnbAmount <= 0) {
            throw new Error('Invalid BNB amount');
        }

        const bnbAmountWei = ethers.parseEther(bnbAmount.toString());
        if (bnbAmountWei > bnbBalance) {
          throw new Error('Insufficient BNB balance');
        }

          // Get gas options and user selection
          const { options: gasOptions, baseFeePerGas } = await getGasOptions(provider);
          const selectedGas = await promptGasSelection(gasOptions, baseFeePerGas);
        console.log(`\nSelected gas option: ${selectedGas.price.toFixed(2)} gwei (Estimated cost: ${selectedGas.costInBNB} BNB)`);

        // Prepare swap parameters
        const path = [WBNB_ADDRESS, config.TOKEN_ADDRESS];
        const amountOutMin = 0; // Set to 0 for testing - in production, calculate minimum amount

        console.log('Executing buy...');
        
        // Create transaction with proper encoding
        const swapData = routerContract.interface.encodeFunctionData(
            'swapExactETHForTokensSupportingFeeOnTransferTokens',
            [amountOutMin, path, wallet.address, DEADLINE]
        );

        // Send transaction with retry logic
        let retryCount = 0;
        const maxRetries = 3;
        let buyReceipt;

        while (retryCount < maxRetries) {
            try {
                const buyTx = await wallet.sendTransaction({
                    to: PANCAKESWAP_ROUTER_ADDRESS,
                    data: swapData,
                    value: bnbAmountWei,
                    gasPrice: ethers.parseUnits(selectedGas.price.toString(), 'gwei'),
                    gasLimit: selectedGas.limit
                });

                console.log('Buy transaction sent. Waiting for confirmation...');
                buyReceipt = await waitForTransaction(provider, buyTx.hash);
                
                if (buyReceipt.status === 1) {
                    break;
                } else {
                    throw new Error('Transaction failed');
                }
            } catch (error) {
                retryCount++;
                if (retryCount === maxRetries) {
                    throw error;
                }
                console.log(`Retry attempt ${retryCount}/${maxRetries}...`);
                selectedGas.price *= 1.1; // Increase gas price by 10% for retry
                await new Promise(resolve => setTimeout(resolve, 2000));
            }
        }

        console.log('\nBuy successful!');
        console.log('Transaction hash:', buyReceipt.hash);
        console.log('Gas used:', buyReceipt.gasUsed.toString());
        console.log(`View on BSCScan: https://bscscan.com/tx/${buyReceipt.hash}`);

    } catch (error) {
        console.error('\nError occurred:', error.reason || error.message);
        if (error.transaction) {
            console.log('\nTransaction details:');
            console.log('Transaction hash:', error.transaction.hash);
            console.log(`View on BSCScan: https://bscscan.com/tx/${error.transaction.hash}`);
        }
        process.exit(1);
    } finally {
        rl.close();
    }
}

// Execute the buy
buyTokensWithBNB().then(() => process.exit(0));
