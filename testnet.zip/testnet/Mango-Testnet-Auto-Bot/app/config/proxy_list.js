export const proxyList = [
  "http://uahwgqcj:8h265nejdgnj@64.137.42.112:5157",
  "http://uahwgqcj:8h265nejdgnj@173.0.9.70:5653",
  "http://uahwgqcj:8h265nejdgnj@173.0.9.209:5792",
  "http://uahwgqcj:8h265nejdgnj@161.123.152.115:6360"

];
